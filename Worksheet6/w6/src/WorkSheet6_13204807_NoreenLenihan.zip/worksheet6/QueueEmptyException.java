package worksheet6;

public class QueueEmptyException extends RuntimeException {

}
