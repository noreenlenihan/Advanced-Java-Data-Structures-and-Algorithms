package w7;

public class QueueFullException extends RuntimeException {

}
