package w7;

public class QueueEmptyException extends RuntimeException {
	

}
