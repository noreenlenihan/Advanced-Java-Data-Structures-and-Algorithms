package Stacks;

public class StackFullException extends RuntimeException {

}
