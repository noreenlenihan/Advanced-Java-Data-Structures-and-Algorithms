package Stacks;

public class StackEmptyException extends RuntimeException {

}
