package Stacks;

public interface Stack {
	public int size();

	public boolean isEmpty();

	public Object pop();

	public void push(Object object);

	public Object top();

}
