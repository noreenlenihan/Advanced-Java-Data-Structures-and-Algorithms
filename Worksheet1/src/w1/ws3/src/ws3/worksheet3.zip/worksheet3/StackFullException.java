package ws3;

public class StackFullException extends RuntimeException {

	

}
