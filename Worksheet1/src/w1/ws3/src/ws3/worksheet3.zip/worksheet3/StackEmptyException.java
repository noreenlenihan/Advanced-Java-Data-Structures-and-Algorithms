package ws3;

public class StackEmptyException extends RuntimeException {

	
	

}
