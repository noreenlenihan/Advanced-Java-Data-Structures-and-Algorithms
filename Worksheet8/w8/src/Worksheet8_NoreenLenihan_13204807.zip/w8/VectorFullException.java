package w8;

public class VectorFullException extends RuntimeException {

}
