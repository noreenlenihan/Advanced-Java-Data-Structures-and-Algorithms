package w8;

public class RankOutOfBoundsException extends RuntimeException {

}
