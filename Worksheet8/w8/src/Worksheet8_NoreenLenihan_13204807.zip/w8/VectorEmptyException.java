package w8;

public class VectorEmptyException extends RuntimeException {

}
